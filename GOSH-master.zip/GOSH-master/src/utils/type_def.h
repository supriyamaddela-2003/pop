#ifndef _TYPE_DEF
#define _TYPE_DEF
typedef float emb_t;
typedef unsigned int vid_t;
#endif
